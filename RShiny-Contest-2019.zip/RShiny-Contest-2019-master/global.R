##Global (Start):====================================================================================

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#--------Script to install missing  Libraries------------------#

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

rm(list=ls())



#Downloading and loading required packages

req_packages <- c("shiny","shinythemes", "dplyr", "DT","RColorBrewer","colourpicker","shinydashboardPlus",
                  "ggplot2", "shinyalert","gtools","rhandsontable",
                  "shinyjs","shinyWidgets",
                  "shinycssloaders","htmltools",
                  "plotly","arules","arulesViz"
)

Packages_TBD <- req_packages[!(req_packages %in% installed.packages()[,"Package"])]
if(length(Packages_TBD)) install.packages(Packages_TBD)




#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#---------Import Libraries------------------#

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


##Library:-------------------------------------------------------------------------------------------
library(shiny)           #Shiny: used for base shiny app
library(shinythemes)     #Shiny: used for shiny themes
library(shinyWidgets)    #Shiny: used for shiny widgets
library(readxl)          #Data & Table: used for excel file import
library(DT)              #Data & Table: used for datatables
library(RColorBrewer)    #Colours: used for colour palettes
library(colourpicker)    #Colours: used for colour selection
library(shinyjs)         # to enable javascript functionality
library(dplyr)
library(DT)
library(ggplot2)
library(shinyalert)
library(shinyjs)
library(shinyWidgets)
library(shinycssloaders)
library(htmltools)
library(plotly)
library(arules)
library(arulesViz)
library(RColorBrewer)
library(shinythemes)
library(shinydashboardPlus)
library(rhandsontable)




##Color Palette:-------------------------------------------------------------------------------------
##Color Groups
ColorGroup_Black = c('#000000','#000000','#000000','#000000','#000000','#000000','#000000','#000000','#000000','#000000','#000000','#000000','#000000','#000000')
ColorGroup_White = c('#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF')

ColorGroup_95ASC = c('#F0F5F5','#FFE9E6','#E6F2FF','#FFFFE6','#EAFAEA','#F2F2F2','#F9EBEB','#EEF2F6','#FCFCE8','#ECF9F2','#FFE6FF','#E6FFFF','#FFF2E6','#F7FFE6')
ColorGroup_90ASC = c('#E0EBEB','#FFD4CC','#CCE6FF','#FFFFCC','#D6F5D6','#E6E6E6','#F3D8D8','#DEE6ED','#FAFAD2','#D9F2E4','#FFCCFF','#CCFFFF','#FFE6CC','#EEFFCC')
ColorGroup_85ASC = c('#D1E0E0','#FFBEB3','#B3D9FF','#FFFFB3','#C1F0C1','#D9D9D9','#EDC4C4','#CDD9E4','#F7F7BA','#C6ECD7','#FFB3FF','#B3FFFF','#FFD9B3','#E6FFB3')
ColorGroup_80ASC = c('#C2D6D6','#FFA899','#99CCFF','#FFFF99','#ADEBAD','#CCCCCC','#E7B1B1','#BDCDDB','#F5F5A3','#B3E6C9','#FF99FF','#99FFFF','#FFCC99','#DDFF99')
ColorGroup_75ASC = c('#B3CCCC','#FF9380','#80BFFF','#FFFF80','#98E698','#BFBFBF','#E19D9D','#ACC0D2','#F2F28C','#9FDFBC','#FF80FF','#80FFFF','#FFBF80','#D5FF80')
ColorGroup_70ASC = c('#A3C2C2','#FF7D66','#66B3FF','#FFFF66','#84E184','#B3B3B3','#DB8A8A','#9CB3C9','#F0F075','#8CD9AF','#FF66FF','#66FFFF','#FFB366','#CCFF66')
ColorGroup_65ASC = c('#94B8B8','#FF674D','#4DA6FF','#FFFF4D','#6FDC6F','#A6A6A6','#D57676','#8BA7C1','#EDED5E','#79D2A1','#FF4DFF','#4DFFFF','#FFA64D','#C4FF4D')
ColorGroup_60ASC = c('#85ADAD','#FF5233','#3399FF','#FFFF33','#5BD75B','#999999','#CF6363','#7A9AB8','#EBEB47','#66CC94','#FF33FF','#33FFFF','#FF9933','#BBFF33')
ColorGroup_55ASC = c('#75A3A3','#FF3C1A','#1A8CFF','#FFFF1A','#46D246','#8C8C8C','#C94F4F','#6A8DAF','#E8E830','#53C687','#FF1AFF','#1AFFFF','#FF8C1A','#B3FF1A')
ColorGroup_50ASC = c('#669999','#FF2600','#0080FF','#FFFF00','#32CD32','#808080','#C33C3C','#5981A6','#E6E619','#40BF79','#FF00FF','#00FFFF','#FF8000','#AAFF00')
ColorGroup_45ASC = c('#5C8A8A','#E62200','#0073E6','#E6E600','#2DB92D','#737373','#B03636','#507495','#CFCF17','#39AC6D','#E600E6','#00E6E6','#E67300','#99E600')
ColorGroup_40ASC = c('#527A7A','#CC1F00','#0066CC','#CCCC00','#28A428','#666666','#9C3030','#476785','#B8B814','#339961','#CC00CC','#00CCCC','#CC6600','#88CC00')
ColorGroup_35ASC = c('#476B6B','#B31B00','#0059B3','#B3B300','#239023','#595959','#892A2A','#3E5A74','#A1A112','#2D8655','#B300B3','#00B3B3','#B35900','#77B300')
ColorGroup_30ASC = c('#3D5C5C','#991700','#004D99','#999900','#1E7B1E','#4D4D4D','#752424','#364D63','#8A8A0F','#267349','#990099','#009999','#994D00','#669900')
ColorGroup_25ASC = c('#334D4D','#801300','#004080','#808000','#196719','#404040','#621E1E','#2D4053','#73730D','#20603D','#800080','#008080','#804000','#558000')
ColorGroup_20ASC = c('#293D3D','#660F00','#003366','#666600','#145214','#333333','#4E1818','#243442','#5C5C0A','#194D30','#660066','#006666','#663300','#446600')
ColorGroup_15ASC = c('#1F2E2E','#4D0B00','#00264D','#4D4D00','#0F3E0F','#262626','#3B1212','#1B2732','#454508','#133924','#4D004D','#004D4D','#4D2600','#334D00')
ColorGroup_10ASC = c('#141F1F','#330800','#001A33','#333300','#0A290A','#1A1A1A','#270C0C','#121A21','#2E2E05','#0D2618','#330033','#003333','#331A00','#223300')
ColorGroup_05ASC = c('#0A0F0F','#1A0400','#000D1A','#1A1A00','#051505','#0D0D0D','#140606','#090D11','#171703','#06130C','#1A001A','#001A1A','#1A0D00','#111A00')

ColorGroup_95DSC = c('#ECF9F2','#FCFCE8','#EEF2F6','#F9EBEB','#F2F2F2','#EAFAEA','#FFFFE6','#E6F2FF','#FFE9E6','#F0F5F5','#F7FFE6','#FFF2E6','#E6FFFF','#FFE6FF')
ColorGroup_90DSC = c('#D9F2E4','#FAFAD2','#DEE6ED','#F3D8D8','#E6E6E6','#D6F5D6','#FFFFCC','#CCE6FF','#FFD4CC','#E0EBEB','#EEFFCC','#FFE6CC','#CCFFFF','#FFCCFF')
ColorGroup_85DSC = c('#C6ECD7','#F7F7BA','#CDD9E4','#EDC4C4','#D9D9D9','#C1F0C1','#FFFFB3','#B3D9FF','#FFBEB3','#D1E0E0','#E6FFB3','#FFD9B3','#B3FFFF','#FFB3FF')
ColorGroup_80DSC = c('#B3E6C9','#F5F5A3','#BDCDDB','#E7B1B1','#CCCCCC','#ADEBAD','#FFFF99','#99CCFF','#FFA899','#C2D6D6','#DDFF99','#FFCC99','#99FFFF','#FF99FF')
ColorGroup_75DSC = c('#9FDFBC','#F2F28C','#ACC0D2','#E19D9D','#BFBFBF','#98E698','#FFFF80','#80BFFF','#FF9380','#B3CCCC','#D5FF80','#FFBF80','#80FFFF','#FF80FF')
ColorGroup_70DSC = c('#8CD9AF','#F0F075','#9CB3C9','#DB8A8A','#B3B3B3','#84E184','#FFFF66','#66B3FF','#FF7D66','#A3C2C2','#CCFF66','#FFB366','#66FFFF','#FF66FF')
ColorGroup_65DSC = c('#79D2A1','#EDED5E','#8BA7C1','#D57676','#A6A6A6','#6FDC6F','#FFFF4D','#4DA6FF','#FF674D','#94B8B8','#C4FF4D','#FFA64D','#4DFFFF','#FF4DFF')
ColorGroup_60DSC = c('#66CC94','#EBEB47','#7A9AB8','#CF6363','#999999','#5BD75B','#FFFF33','#3399FF','#FF5233','#85ADAD','#BBFF33','#FF9933','#33FFFF','#FF33FF')
ColorGroup_55DSC = c('#53C687','#E8E830','#6A8DAF','#C94F4F','#8C8C8C','#46D246','#FFFF1A','#1A8CFF','#FF3C1A','#75A3A3','#B3FF1A','#FF8C1A','#1AFFFF','#FF1AFF')
ColorGroup_50DSC = c('#40BF79','#E6E619','#5981A6','#C33C3C','#808080','#32CD32','#FFFF00','#0080FF','#FF2600','#669999','#AAFF00','#FF8000','#00FFFF','#FF00FF')
ColorGroup_45DSC = c('#39AC6D','#CFCF17','#507495','#B03636','#737373','#2DB92D','#E6E600','#0073E6','#E62200','#5C8A8A','#99E600','#E67300','#00E6E6','#E600E6')
ColorGroup_40DSC = c('#339961','#B8B814','#476785','#9C3030','#666666','#28A428','#CCCC00','#0066CC','#CC1F00','#527A7A','#88CC00','#CC6600','#00CCCC','#CC00CC')
ColorGroup_35DSC = c('#2D8655','#A1A112','#3E5A74','#892A2A','#595959','#239023','#B3B300','#0059B3','#B31B00','#476B6B','#77B300','#B35900','#00B3B3','#B300B3')
ColorGroup_30DSC = c('#267349','#8A8A0F','#364D63','#752424','#4D4D4D','#1E7B1E','#999900','#004D99','#991700','#3D5C5C','#669900','#994D00','#009999','#990099')
ColorGroup_25DSC = c('#20603D','#73730D','#2D4053','#621E1E','#404040','#196719','#808000','#004080','#801300','#334D4D','#558000','#804000','#008080','#800080')
ColorGroup_20DSC = c('#194D30','#5C5C0A','#243442','#4E1818','#333333','#145214','#666600','#003366','#660F00','#293D3D','#446600','#663300','#006666','#660066')
ColorGroup_15DSC = c('#133924','#454508','#1B2732','#3B1212','#262626','#0F3E0F','#4D4D00','#00264D','#4D0B00','#1F2E2E','#334D00','#4D2600','#004D4D','#4D004D')
ColorGroup_10DSC = c('#0D2618','#2E2E05','#121A21','#270C0C','#1A1A1A','#0A290A','#333300','#001A33','#330800','#141F1F','#223300','#331A00','#003333','#330033')
ColorGroup_05DSC = c('#06130C','#171703','#090D11','#140606','#0D0D0D','#051505','#1A1A00','#000D1A','#1A0400','#0A0F0F','#111A00','#1A0D00','#001A1A','#1A001A')


##Global Palette
ui_Global_Palette = list(
  'RowA1' = ColorGroup_Black,
  'RowA2' = ColorGroup_White,
  'RowB0' = ColorGroup_50ASC,
  'RowB1' = ColorGroup_25ASC,
  'RowB2' = ColorGroup_35ASC,
  'RowB3' = ColorGroup_45ASC,
  'RowB4' = ColorGroup_55ASC,
  'RowB5' = ColorGroup_65ASC,
  'RowB6' = ColorGroup_75ASC
  )




#----------------- Convert Item Freq to GGplot ------------------------#
itemFrequencyGGPlot <- function(x, topN) {
  library(tidyverse)
  a1=  x %>%
    itemFrequency %>%
    sort %>%
    tail(topN) %>%
    as.data.frame %>%
    tibble::rownames_to_column()
  library(scales)
  colnames(a1)[1] <-"Item" 
  colnames(a1)[2] <- "Item Frequency (absolute)"
  
  colourCount = length(unique(a1$Item))
  getPalette = colorRampPalette(brewer.pal(9, "Paired"))
  
  
  p <-   ggplot(a1,aes(reorder(Item, -`Item Frequency (absolute)`),`Item Frequency (absolute)`,fill=Item)) + 
    geom_bar(stat="identity", color="black", position=position_dodge())+
    theme_minimal() + scale_fill_manual(values = getPalette(colourCount)) +
    ggtitle("Item Frequency Plot") +
    theme(axis.title.x=element_blank(),axis.text.x=element_blank(),axis.ticks.x=element_blank(),legend.position = "none")
  
  
  ggplotly(p)
  
}




##Global (End):======================================================================================
