# Shiny-Contest

Hey All,
     Many of us develop a Dashboard, but my focus was to build product in Shiny R. 
     
To give you all a walk-through, I have used *Modular Programming* where I have broken my **server** and **ui** logics into separate source files(Scripts)*. 

*Why to do so ?*  Imagine that you have a requirement to develop 7- 8  tab-panels within short deadline. There will be a need to split the work among colleagues so that each colleague would work on only 1/2 tabs/modules. This can be accomplished using Modular Programming. It not only saves time, but also improves code readability. 

Now, moving towards UI enhancements, I have defined custom settings using **html tags**, by means of which user can select the theme-color, as well as font style.

Just to showcase a business scenario, 

I took the example of Market Basket Analysis for [groceries data](http://www.sci.csueastbay.edu/~esuess/classes/Statistics_6620/Presentations/ml13/groceries.csv). 
This scenario was already statically showcased at 
[https://rstudio-pubs-static.s3.amazonaws.com/280759_c7acd79b21b24b959f58d9bf8b519cf8.html](https://rstudio-pubs-static.s3.amazonaws.com/280759_c7acd79b21b24b959f58d9bf8b519cf8.html).

Initially on Data Upload, we can see the summary of Transactional Data as well few records. In **Produc Association Tab**, I have implemented ***Apriori Algorithm*** with default parameters which can later be updated. The changes made on updation are being showcased on table showing **Product Association Summary**. 

The plot on right hand side shows *Top 10 Frequent Items*, which can be updated by changing the sliders.

**Imp. Links :**

* RStudio Cloud: https://rstudio.cloud/project/253380

* Shinyapps: https://gauravgchavan91.shinyapps.io/mba1/


