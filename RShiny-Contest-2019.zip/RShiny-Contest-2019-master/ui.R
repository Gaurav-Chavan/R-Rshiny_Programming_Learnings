##Ui (Start):========================================================================================

ui = bootstrapPage(title="Product Associations Dashboard",
    
  
  # Enable Js components
  useShinyjs(),
  
  # Enable ShinydasboardPlus
  useShinydashboardPlus(),
  
  # theme set to "Yeti"
  theme = shinytheme("yeti"),
  
  
  
  #----------------- Emabling Custom Tags ---------#
  
  # numeric input width
  tags$head(
    tags$style(type="text/css", "#inline label{ display: table-cell; text-align: left; vertical-align: middle;padding-right:5px } 
                                 #inline .form-group { display: table-row;}")
  ),
  
  tags$style(HTML("input[type=\"number\"] {
                                    width: 100px;
                                    }
                                    
                                    ")),
  
  
  # Removes spin wheels from numeric inputs
  tags$style(HTML("
                  input[type=number] {
                  -moz-appearance:textfield;
                  }
                  input[type=number]::{
                  -moz-appearance:textfield;
                  }
                  input[type=number]::-webkit-outer-spin-button,
                  input[type=number]::-webkit-inner-spin-button {
                  -webkit-appearance: none;
                  margin: 0;
                  }
                  ")),
                    
                    # Centres Box Title
                    tags$head(tags$style(HTML("
                                              div.box-header {
                                              text-align: center;
                                              font-family: Georgia;
                                              font-weight: bold;
                                              
                                              }
                                              "))),
  
  
  #--- Hide Inital Loading Error messages --#
  
  tags$style(type="text/css",
             ".shiny-output-error { visibility: hidden; }",
             ".shiny-output-error:before { visibility: hidden; }"
  ),
  
  

  #------------- Activate settings --------------------#
  
  uiOutput("ui_Home_Theme"),   #Theme Settings
  uiOutput("ui_Home_Page"),    #Page Settings
  uiOutput("ui_Home_Center"),  #Alignment Settings
  
  uiOutput("ui_Home_Page01"), #Change all fonts as per selection
  uiOutput("ui_Home_Page02"), #Body with white color
  uiOutput("ui_Home_Page03"), #Navbar Color & Font
  uiOutput("ui_Home_Page04"), #Navbar brand at Left
  uiOutput("ui_Home_Page05"), #Navbar nav at Right
  uiOutput("ui_Home_Page06"), #Navbar nav active contrast
  uiOutput("ui_Home_Page07"), #Navbar nav inactive contrast
  uiOutput("ui_Home_Page08"), #Icon color
  uiOutput("ui_Home_Page09"), #Reset Button color
  
  ##Navigation:--------------------------------------------------------------------------------------
  navbarPage(
    id = "Mba_Navigation",
    position = "fixed-top",
    title = column(12, class = "Home_Theme", class = "Home_Center", style = "height: 150%;", a(img(src = "01.png", height = "100%"), href = "https://www.linkedin.com/in/gauravgchavan/", target = "_blank")),
    selected = "Home",
    
    ##Header
    fluidRow(
      column(12, class = "Home_Theme", class = "Home_Center", style = "height: 050px;", ""),
      column(12, class = "Home_Theme", class = "Home_Center", style = "height: 150px;", img(src = "02.png", height = "100%")),
      column(12, class = "Home_Theme", class = "Home_Center", style = "height: 005px;", "")
      ),
    
    
    ##Tabs
    source(file.path("modules", "Module_Home_Ui.R"),  local = TRUE)$value,
    
    

    
    navbarMenu("Association Rule Mining",
               icon = icon("chart-bar", lib = "font-awesome"),
               
               # breaking the ui into modules  This is Market Basket Analysis Tab
               source(file.path("modules", "Module_MBA_Ui.R"),  local = TRUE)$value,
               
               # breaking the ui into modules  This is Product Association Tab
               source(file.path("modules", "Module_Product_Assoc_Ui.R"),  local = TRUE)$value

                              ),
    
    ##Footer 
    fluidRow(
      column(12, class = "Home_Theme", class = "Home_Center", style = "height: 025px;", "All rights reserved | Cookie Policy | Privacy Policy"),
      column(12, class = "Home_Theme", class = "Home_Center", style = "height: 100px;", "")
      )
    
    )
  
  )

##Ui (End):==========================================================================================
