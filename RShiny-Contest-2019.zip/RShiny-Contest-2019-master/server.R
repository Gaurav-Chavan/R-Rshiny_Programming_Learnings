##Server (Start):====================================================================================

server = function(input, output, session) {
  
  
  ##Define Settings
  output$ui_Home_Theme  = renderUI({ tags$style(HTML(paste0('.Home_Theme  {background-color: ',input$in_Home_ThemeColor,'; color: #FFFFFF}'))) })
  output$ui_Home_Page   = renderUI({ tags$style(HTML(paste0('.Home_Page   {background-color: #FFFFFF;}'))) })
  output$ui_Home_Center = renderUI({ tags$style(HTML(paste0('.Home_Center {text-align: center; vertical-align: middle;}'))) })
  output$ui_Home_Page01 = renderUI({ tags$style(HTML(paste0('* {font-family: ',input$in_Home_FontFamily,';}'))) })
  output$ui_Home_Page02 = renderUI({ tags$style(HTML(paste0('body {background-color: #FFFFFF;}'))) })
  output$ui_Home_Page03 = renderUI({ tags$style(HTML(paste0('.navbar {background-color: ',input$in_Home_ThemeColor,'; color: #FFFFFF; font-size: 18px; margin-bottom: 0!important;}'))) })
  output$ui_Home_Page04 = renderUI({ tags$style(HTML(paste0('.navbar-brand    {float: left;}'))) })
  output$ui_Home_Page05 = renderUI({ tags$style(HTML(paste0('.navbar-nav      {float: right;}'))) })
  output$ui_Home_Page06 = renderUI({ tags$style(HTML(paste0('.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:focus, .navbar-default .navbar-nav > .active > a:hover {background-color: ',input$in_Home_ThemeColor,'; filter: contrast(70%);}'))) })
  output$ui_Home_Page07 = renderUI({ tags$style(HTML(paste0('.navbar-default .navbar-nav > li > a:hover {background-color: ',input$in_Home_ThemeColor,'; filter: contrast(70%);}'))) })
  output$ui_Home_Page08 = renderUI({ tags$style(HTML(paste0('.bttn-bordered.bttn-default {background-color: #FFFFFF; color: ',input$in_Home_ThemeColor,';}'))) })
  output$ui_Home_Page09 = renderUI({ tags$style(HTML(paste0('.bttn-stretch.bttn-default  {background-color: ',input$in_Home_ThemeColor,'; color: #FFFFFF;}'))) })
  
  
  
  ##Tab Panels (SERVER)
  source(file.path("modules", "Module_Product_Assoc_Server.R"),  local = TRUE)$value
  source(file.path("modules", "Module_MBA_Server.R"),  local = TRUE)$value
  
  
  
  }

##Server (End):======================================================================================
