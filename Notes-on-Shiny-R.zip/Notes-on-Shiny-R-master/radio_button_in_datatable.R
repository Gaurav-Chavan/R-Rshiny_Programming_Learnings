library(shiny)
library(data.table)
library(DT)
shinyApp(
  ui = fluidPage(
    title = 'Radio buttons in a table',
    DT::dataTableOutput('foo'),
    verbatimTextOutput('sel'), verbatimTextOutput('x2')
    
  ),
  server = function(input, output, session) {
    
    x <- data.table( 'Breed Split' = paste0("F",rep(0:16)), Frisian = rep(1,17), Cross = rep(2,17), Jersey = rep(3,17) ,
                     checked=c(rep("Frisian",9),rep("Cross",5),rep("Jersey",3))
    )
    
    x[, Frisian := sprintf( '<input type="radio" name="%s" value="%s" %s/>', `Breed Split`, x[, Frisian],ifelse("Frisian"==x[, checked],"checked" ,""))]
    x[, Cross := sprintf( '<input type="radio" name="%s" value="%s" %s/>', `Breed Split`, x[, Cross],ifelse("Cross"==x[, checked],"checked" ,"" ))]
    x[, Jersey := sprintf( '<input type="radio" name="%s" value="%s" %s/>', `Breed Split`, x[, Jersey] ,ifelse("Jersey"==x[, checked],"checked" ,""))]
    
    output$foo = DT::renderDataTable(
      x[,-c("checked")], escape = FALSE, selection = 'none', server = FALSE, rownames=FALSE,
      options = list(dom = 't', paging = FALSE, ordering = FALSE),
      callback = JS("table.rows().every(function(i, tab, row) {
                    var $this = $(this.node());
                    $this.attr('id', this.data()[0]);
                    $this.addClass('shiny-input-radiogroup');
  });
                    Shiny.unbindAll(table.table().node());
                    Shiny.bindAll(table.table().node());")
    )
    
    inputs <- reactive ({ str(sapply(x$`Breed Split`, function(i) input[[i]])) })
    output$sel = renderPrint({ sapply(x$`Breed Split`, function(i) input[[i]]) })
    
    }
    )
