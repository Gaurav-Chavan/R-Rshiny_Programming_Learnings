library(shinyjs)
library(shiny)
runApp(shinyApp(
  ui = fluidPage(
    shinyjs::useShinyjs(),
    div(
      id = "form",
      textInput("text", "Text", ""),
      selectInput("select", "Select", 1:5),
      actionButton("refresh", "Refresh")
    )
  ),
  server = function(input, output, session) {
    observeEvent(input$refresh, {
      shinyjs::reset("form")
    })
  }
))