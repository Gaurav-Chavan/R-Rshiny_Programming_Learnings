library(shiny)
library(DT)
library(data.table)
shinyApp(
  ui = fluidPage(
    title = 'Radio buttons in a table',
    DT::dataTableOutput('foo'),
    verbatimTextOutput('sel')
  ),
  server = function(input, output, session) {
    
    m = data.table(
      month1 = month.abb,
      A = '1',
      B = '2',
      C = '3',
      QWE = runif(12)
    )
    m[, A := sprintf(
      '<input type="radio" name="%s" value="%s"/>',
      month1, m[, A]
    )]
    m[, B := sprintf(
      '<input type="radio" name="%s" value="%s"/>',
      month1, m[, B]
    )]
    m[, C := sprintf(
      '<input type="radio" name="%s" value="%s"/>',
      month1, m[, C]
    )]
    
    output$foo = DT::renderDataTable(
      m, escape = FALSE, selection = 'none', server = FALSE, rownames=FALSE,
      options = list(dom = 't', paging = FALSE, ordering = FALSE),
      callback = JS("table.rows().every(function(i, tab, row) {
                    var $this = $(this.node());
                    $this.attr('id', this.data()[0]);
                    $this.addClass('shiny-input-radiogroup');
  });
                    Shiny.unbindAll(table.table().node());
                    Shiny.bindAll(table.table().node());")
    )
    output$sel = renderPrint({
      str(sapply(month.abb, function(i) input[[i]]))
    })
    }
)
