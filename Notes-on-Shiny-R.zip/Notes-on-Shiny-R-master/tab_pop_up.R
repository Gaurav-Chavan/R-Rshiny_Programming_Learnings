library(shiny)
library(shinyjs)

ui <- tagList(
  useShinyjs(),
  a
  navbarPage(
    "shinyjs with navbarPage",
    id = "navbar",
    tabPanel(
      title = "tab1",
      actionButton("button", "Click me")
    ),
    tabPanel(
      title = "Cool Tab 2",
      value = "mytab2",
      sidebarLayout(
        sidebarPanel(
          selectInput("test", "Choose a variable", choices = c("var1", "var2"), selected = "var1")
        ),
        mainPanel(
          textOutput("testOut")
        )
      )
    )
  )
)

server <- function(input, output, session) {
  observe({
    hide(selector = "#navbar li a[data-value=mytab2]")
  })
  output$testOut <- renderText({
    paste("Your choice is", input$test)
  })
  observeEvent(input$button, {
    toggle(selector = "#navbar li a[data-value=mytab2]")
  })
}
shinyApp(ui = ui, server = server)