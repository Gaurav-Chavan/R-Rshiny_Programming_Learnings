# Shiny-R

#  Code Snippets

https://www.kaggle.com/mrisdal/exploring-survival-on-the-titanic
