############ continuous variables #################

ggplot(train, aes(ID, Hours.Per.Week)) + geom_jitter() 
