# Sample-Code-Functions

 Contains R code Snippets for solving ML Problems  

## Adding
- Train test split
- Caret Modelling Regression
- Caret Modelling Classification
- Ensemble Learning in Caret
- Feature Selection Techniques
- Ensemble Learning
- H2o Modelling
- H2o Automl
